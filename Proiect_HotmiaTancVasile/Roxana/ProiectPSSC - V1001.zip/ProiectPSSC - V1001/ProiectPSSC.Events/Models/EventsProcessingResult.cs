﻿namespace ProiectPSSC.Events.Models
{
    public enum EventProcessingResult
    {
        Completed,
        Retry,
        Failed
    }
}
