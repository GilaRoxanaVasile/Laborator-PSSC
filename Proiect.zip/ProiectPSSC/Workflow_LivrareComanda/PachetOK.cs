﻿namespace Workflow_LivrareComanda
{
    public class PachetOK
    {


    }
}